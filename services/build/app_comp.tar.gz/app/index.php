<html>
 <head>
  <title>PHP Test</title>
 </head>
 <body>
    <h1>
        <?php echo 'youcan.shop is server now right now by the host :', getHostByName(getHostName()); ?> 
    </h1>
 </body>
</html>
