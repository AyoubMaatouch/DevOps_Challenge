<html>
 <head>
  <title>PHP Test</title>
 </head>
 <body>
    <h1>
        <?php echo 'youcan.shop is server now by ', getHostByName(getHostName()); ?> 
    </h1>
 </body>
</html>